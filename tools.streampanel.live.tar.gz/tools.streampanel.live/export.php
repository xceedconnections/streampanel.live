<?php
// Allow larger exports for big M3U files (tune as needed for XAMPP)
@ini_set('memory_limit', '512M');
@set_time_limit(300);

error_reporting(0);
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx as XlsxReader;

session_start();
$rawInput = file_get_contents('php://input');
$data     = json_decode($rawInput, true);

// If data is posted directly, use it; otherwise use session
if (is_array($data) && !empty($data)) {
    $channels = $data;
} else {
    $channels = $_SESSION['channels'] ?? [];
}

// If no channels data, return empty
if (empty($channels)) {
    echo "No data to export";
    exit;
}

// Helper: clean channel name similar to parse/index
function cleanChannelNameForMatch($name)
{
    if (!is_string($name)) {
        return '';
    }

    // Remove content in parentheses like (720p)
    $cleaned = preg_replace('/\s*\([^)]*\)/', '', $name);
    // Remove content in brackets like [Not 24/7]
    $cleaned = preg_replace('/\s*\[[^\]]*\]/', '', $cleaned);
    // Trim extra spaces
    $cleaned = trim($cleaned);

    return $cleaned;
}

// Load DB file (db.xlsx) and build channel -> [country, category] map
$dbMap           = [];
$dbHasCountry    = false;
$dbHasCategory   = false;
$dbFile          = __DIR__ . DIRECTORY_SEPARATOR . 'db.xlsx';

if (file_exists($dbFile)) {
    try {
        $reader        = new XlsxReader();
        // We only need values, not styles, to keep memory lower
        $reader->setReadDataOnly(true);
        $dbSpreadsheet = $reader->load($dbFile);
        $dbSheet       = $dbSpreadsheet->getActiveSheet();
        $dbRows        = $dbSheet->toArray(null, true, true, true); // rows with A,B,C... keys

        if (!empty($dbRows)) {
            // First row is assumed to be headers
            $headerRow = array_shift($dbRows);
            $colMap    = [
                'channel'  => null,
                'country'  => null,
                'category' => null,
            ];

            foreach ($headerRow as $col => $value) {
                $label = strtolower(trim((string) $value));
                // Match "channel name" (exact), "channel", or "name"
                if (in_array($label, ['channel name', 'channel', 'name'], true)) {
                    $colMap['channel'] = $col;
                } elseif ($label === 'country') {
                    $colMap['country'] = $col;
                    $dbHasCountry      = true;
                } elseif (in_array($label, ['category', 'group'], true)) {
                    $colMap['category'] = $col;
                    $dbHasCategory      = true;
                }
            }

            if ($colMap['channel'] !== null) {
                foreach ($dbRows as $row) {
                    $rawName = $row[$colMap['channel']] ?? '';
                    $clean   = cleanChannelNameForMatch($rawName);
                    $key     = strtolower($clean);
                    if ($key === '') {
                        continue;
                    }

                    $dbMap[$key] = [
                        'country'  => $colMap['country'] !== null ? ($row[$colMap['country']] ?? '') : '',
                        'category' => $colMap['category'] !== null ? ($row[$colMap['category']] ?? '') : '',
                    ];
                }
            }
        }
    } catch (\Throwable $e) {
        // If DB cannot be read for any reason, skip mapping and export original data
        $dbMap         = [];
        $dbHasCountry  = false;
        $dbHasCategory = false;
    }
}

$s     = new Spreadsheet();
$sheet = $s->getActiveSheet()->setTitle('IPTV Channels');

// Headers: Name, Country (from db), Category (from db or group), TVG, Logo, URL, Status
$heads = ['Name', 'Country', 'Category', 'TVG', 'Logo', 'URL', 'Status'];
$sheet->fromArray($heads, null, 'A1');

// Apply header styling
$headerStyle = [
    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
    'fill' => [
        'fillType'   => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
        'startColor' => ['rgb' => '4e54c8'],
    ],
];

for ($col = 'A'; $col <= 'G'; $col++) {
    $sheet->getStyle($col . '1')->applyFromArray($headerStyle);
}

$row = 2;
foreach ($channels as $c) {
    // Clean up channel name - remove resolution and other info in parentheses
    $rawName     = $c['name'] ?? '';
    $channelName = cleanChannelNameForMatch($rawName);

    // Default values from uploaded playlist
    $playlistCountry  = ''; // playlist does not currently have country
    $playlistCategory = $c['group'] ?? '';

    // Try to override from DB using cleaned, lowercase channel name
    $lookupKey = strtolower($channelName);
    $country   = $playlistCountry;
    $category  = $playlistCategory;

    if ($lookupKey !== '' && isset($dbMap[$lookupKey])) {
        $dbEntry = $dbMap[$lookupKey];

        // DB is 100% correct; always override from DB (even if empty)
        if ($dbHasCountry) {
            $country = $dbEntry['country'] ?? '';
        }
        if ($dbHasCategory) {
            // DB is 100% correct; override category/group
            $category = $dbEntry['category'] ?? '';
        }
    }

    $rowData = [
        $channelName,
        $country,
        $category,
        $c['tvg'] ?? '',
        $c['logo'] ?? '',
        $c['url'] ?? '',
        $c['status'] ?? 'unknown',
    ];

    $sheet->fromArray($rowData, null, "A$row");

    // Apply conditional formatting for status (column G)
    $statusCell = "G$row";
    $status     = strtolower($c['status'] ?? '');

    if ($status === 'active') {
        $sheet->getStyle($statusCell)
            ->getFill()
            ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
            ->getStartColor()
            ->setRGB('C6F6D5');
        $sheet->getStyle($statusCell)
            ->getFont()
            ->getColor()
            ->setRGB('22543D');
    } elseif ($status === 'inactive') {
        $sheet->getStyle($statusCell)
            ->getFill()
            ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
            ->getStartColor()
            ->setRGB('FED7D7');
        $sheet->getStyle($statusCell)
            ->getFont()
            ->getColor()
            ->setRGB('742A2A');
    }

    $row++;
}

// Auto-size columns
foreach (range('A', 'G') as $column) {
    $sheet->getColumnDimension($column)->setAutoSize(true);
}

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="iptv_channels_' . date('Y-m-d_H-i-s') . '.xlsx"');
$w = new Xlsx($s);
$w->save('php://output');
exit;