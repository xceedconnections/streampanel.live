<!DOCTYPE html>
<html>
<head>
<title>IPTV M3U Checker</title>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    padding: 20px;
}

.container {
    max-width: 1400px;
    margin: 0 auto;
    background: white;
    border-radius: 15px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.2);
    overflow: hidden;
}

.header {
    background: linear-gradient(135deg, #4e54c8, #8f94fb);
    color: white;
    padding: 30px;
    text-align: center;
}

.header h1 {
    font-size: 2.5rem;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
}

.header p {
    opacity: 0.9;
    font-size: 1.1rem;
}

.controls {
    padding: 25px;
    background: #f8f9fa;
    border-bottom: 2px solid #e9ecef;
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    align-items: center;
}

.file-input {
    flex: 1;
    min-width: 300px;
}

.btn {
    padding: 12px 25px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    font-size: 15px;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px;
}

.btn-primary {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 7px 14px rgba(102, 126, 234, 0.3);
}

.btn-success {
    background: linear-gradient(135deg, #42b883, #347474);
    color: white;
}

.btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 7px 14px rgba(66, 184, 131, 0.3);
}

.btn-warning {
    background: linear-gradient(135deg, #ff9a3c, #ff6f3c);
    color: white;
}

.btn-warning:hover {
    transform: translateY(-2px);
    box-shadow: 0 7px 14px rgba(255, 154, 60, 0.3);
}

#m3u {
    padding: 12px;
    border: 2px dashed #667eea;
    border-radius: 8px;
    width: 100%;
    font-size: 15px;
}

.status-bar {
    padding: 15px 25px;
    background: #fff3cd;
    border-left: 4px solid #ffc107;
    margin: 0 25px 25px;
    border-radius: 8px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.stats {
    display: flex;
    gap: 20px;
}

.stat {
    padding: 8px 15px;
    border-radius: 6px;
    font-weight: 600;
}

.stat.active {
    background: #d4edda;
    color: #155724;
}

.stat.inactive {
    background: #f8d7da;
    color: #721c24;
}

.stat.total {
    background: #d1ecf1;
    color: #0c5460;
}

.table-container {
    padding: 0 25px 25px;
    overflow-x: auto;
    max-height: 600px;
    overflow-y: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}

thead {
    background: linear-gradient(135deg, #4e54c8, #8f94fb);
    color: white;
    position: sticky;
    top: 0;
    z-index: 10;
}

th {
    padding: 18px 15px;
    text-align: left;
    font-weight: 600;
    font-size: 15px;
}

td {
    padding: 15px;
    border-bottom: 1px solid #f1f1f1;
    vertical-align: middle;
}

tbody tr:hover {
    background-color: #f8f9fa;
}

tr.active {
    background-color: #f0fff4 !important;
    border-left: 4px solid #42b883;
}

tr.inactive {
    background-color: #fff5f5 !important;
    border-left: 4px solid #f56565;
}

.status-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-badge.active {
    background: #c6f6d5;
    color: #22543d;
}

.status-badge.inactive {
    background: #fed7d7;
    color: #742a2a;
}

.logo-cell img {
    height: 40px;
    width: 40px;
    object-fit: cover;
    border-radius: 6px;
    border: 2px solid #e9ecef;
}

.url-cell {
    max-width: 300px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-family: 'Courier New', monospace;
    font-size: 13px;
    color: #666;
}

.channel-name {
    font-weight: 600;
    color: #333;
}

.footer {
    text-align: center;
    padding: 20px;
    color: #666;
    border-top: 1px solid #e9ecef;
    font-size: 14px;
}
</style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1><i class="fas fa-tv"></i> IPTV M3U Checker</h1>
        <p>Upload your M3U file to check channel availability and export results</p>
    </div>

    <div class="controls">
        <div class="file-input">
            <input type="file" id="m3u" accept=".m3u,.m3u8">
        </div>
        <button id="parse" class="btn btn-primary">
            <i class="fas fa-file-import"></i> Parse File
        </button>
        <button id="check" class="btn btn-success">
            <i class="fas fa-play-circle"></i> Check Active
        </button>
        <button id="export" class="btn btn-warning">
            <i class="fas fa-file-excel"></i> Export Excel
        </button>
    </div>

    <div class="status-bar" id="statusBar" style="display: none;">
        <div id="status">Ready</div>
        <div class="stats">
            <div class="stat total">
                <i class="fas fa-list"></i> Total: <span id="totalCount">0</span>
            </div>
            <div class="stat active">
                <i class="fas fa-check-circle"></i> Active: <span id="activeCount">0</span>
            </div>
            <div class="stat inactive">
                <i class="fas fa-times-circle"></i> Inactive: <span id="inactiveCount">0</span>
            </div>
        </div>
    </div>

    <div class="table-container">
        <table id="table">
            <thead>
                <tr>
                    <th width="60">Logo</th>
                    <th width="250">Channel Name</th>
                    <th width="120">TVG ID</th>
                    <th width="150">Group</th>
                    <th>URL</th>
                    <th width="100">Status</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

    <div class="footer">
        <p>IPTV Checker v1.0 &copy; 2024 | Check your M3U playlist channels status</p>
    </div>
</div>

<script>
let channels = [];

// Function to clean channel name
function cleanChannelName(name) {
    if (!name) return '';
    // Remove content in parentheses like (720p), (576p), etc.
    let cleaned = name.replace(/\s*\([^)]*\)/g, '');
    // Remove content in brackets like [Not 24/7], etc.
    cleaned = cleaned.replace(/\s*\[[^\]]*\]/g, '');
    // Trim extra spaces
    cleaned = cleaned.trim();
    return cleaned || name;
}

function updateStats() {
    const total = channels.length;
    const active = channels.filter(c => c.status === 'active').length;
    const inactive = channels.filter(c => c.status === 'inactive').length;
    
    $('#totalCount').text(total);
    $('#activeCount').text(active);
    $('#inactiveCount').text(inactive);
    $('#statusBar').show();
}

$('#parse').click(function(){
    const file = $('#m3u')[0].files[0];
    if (!file) {
        alert('Please select an M3U file first');
        return;
    }
    
    $('#status').html('<i class="fas fa-spinner fa-spin"></i> Parsing file...');
    $('#statusBar').show();
    
    let f = new FormData();
    f.append('m3u', file);
    
    $.ajax({
        url: 'parse.php',
        method: 'POST',
        data: f,
        processData: false,
        contentType: false,
        success: function(r){
            channels = r;
            let html = '';
            r.forEach((c, i) => {
                const cleanedName = cleanChannelName(c.name);
                html += `<tr id="r${i}">
                    <td class="logo-cell">
                        <img src="${c.logo || 'https://via.placeholder.com/40x40/667eea/ffffff?text=TV'}" 
                             onerror="this.src='https://via.placeholder.com/40x40/cccccc/666666?text=No+Logo'">
                    </td>
                    <td>
                        <div class="channel-name">${cleanedName || 'Unknown Channel'}</div>
                        ${cleanedName !== c.name ? `<div style="font-size:12px;color:#999;margin-top:3px;">Original: ${c.name}</div>` : ''}
                    </td>
                    <td>${c.tvg || 'N/A'}</td>
                    <td>${c.group || 'N/A'}</td>
                    <td class="url-cell" title="${c.url}">${c.url}</td>
                    <td><span class="status-badge">Pending</span></td>
                </tr>`;
            });
            
            $('#table tbody').html(html);
            $('#status').html('<i class="fas fa-check-circle"></i> File parsed successfully');
            updateStats();
        },
        error: function() {
            $('#status').html('<i class="fas fa-exclamation-circle"></i> Error parsing file');
        }
    });
});

$('#check').click(function(){
    if (channels.length === 0) {
        alert('Please parse an M3U file first');
        return;
    }
    
    $('#status').html('<i class="fas fa-spinner fa-spin"></i> Checking channels...');
    
    // Update all to checking first
    channels.forEach((c, i) => {
        $(`#r${i} td:last .status-badge`)
            .removeClass('active inactive')
            .addClass('inactive')
            .html('<i class="fas fa-spinner fa-spin"></i> Checking');
    });
    
    // Send in batches to avoid timeout
    const batchSize = 50;
    const batches = [];
    
    for (let i = 0; i < channels.length; i += batchSize) {
        batches.push(channels.slice(i, i + batchSize));
    }
    
    let completedBatches = 0;
    
    batches.forEach((batch, batchIndex) => {
        $.post('check.php', {data: JSON.stringify(batch)}, function(r){
            r.forEach((c, i) => {
                const globalIndex = batchIndex * batchSize + i;
                channels[globalIndex].status = c.status;
                
                const $badge = $(`#r${globalIndex} td:last .status-badge`);
                $badge.removeClass('active inactive').addClass(c.status);
                $badge.html(`<i class="fas fa-${c.status === 'active' ? 'check-circle' : 'times-circle'}"></i> ${c.status}`);
                
                $(`#r${globalIndex}`)
                    .removeClass('active inactive')
                    .addClass(c.status);
            });
            
            completedBatches++;
            if (completedBatches === batches.length) {
                $('#status').html('<i class="fas fa-check-circle"></i> All channels checked');
                updateStats();
            }
        }, 'json').fail(function() {
            completedBatches++;
            if (completedBatches === batches.length) {
                $('#status').html('<i class="fas fa-check-circle"></i> Checking completed');
                updateStats();
            }
        });
    });
});

$('#export').click(function(){
    if (channels.length === 0) {
        alert('No data to export');
        return;
    }
    
    $('#status').html('<i class="fas fa-spinner fa-spin"></i> Generating Excel file...');
    
    $.ajax({
        url: 'export.php',
        method: 'POST',
        data: JSON.stringify(channels),
        contentType: 'application/json',
        xhrFields: {
            responseType: 'blob'
        },
        success: function(data) {
            const a = document.createElement('a');
            const url = window.URL.createObjectURL(data);
            a.href = url;
            a.download = `iptv_channels_${new Date().toISOString().slice(0,10)}.xlsx`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            
            $('#status').html('<i class="fas fa-check-circle"></i> Excel file downloaded');
        },
        error: function() {
            $('#status').html('<i class="fas fa-exclamation-circle"></i> Error generating Excel file');
        }
    });
});
</script>
</body>
</html>