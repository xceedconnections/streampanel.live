<?php
error_reporting(0);
$data=json_decode($_POST['data'],true);

$mh=curl_multi_init();
$chs=[];

foreach($data as $i=>$c){
    $ch=curl_init($c['url']);
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>1,
        CURLOPT_TIMEOUT=>6,
        CURLOPT_FOLLOWLOCATION=>1,
        CURLOPT_SSL_VERIFYPEER=>0
    ]);
    curl_multi_add_handle($mh,$ch);
    $chs[$i]=$ch;
}

do{curl_multi_exec($mh,$run);}while($run);

foreach($chs as $i=>$ch){
    $code=curl_getinfo($ch,CURLINFO_HTTP_CODE);
    $data[$i]['status']=$code==200?'active':'inactive';
    curl_multi_remove_handle($mh,$ch);
}

curl_multi_close($mh);
echo json_encode($data);