<?php
error_reporting(0);
$lines=file($_FILES['m3u']['tmp_name'],FILE_IGNORE_NEW_LINES);
$out=[]; $c=[];

foreach($lines as $l){
    if(strpos($l,'#EXTINF')===0){
        $c=[
            'name'=>'',
            'tvg'=>'',
            'logo'=>'',
            'group'=>'',
            'url'=>''
        ];
        preg_match('/tvg-id="([^"]*)"/',$l,$m); $c['tvg']=$m[1]??'';
        preg_match('/tvg-logo="([^"]*)"/',$l,$m); $c['logo']=$m[1]??'';
        preg_match('/group-title="([^"]*)"/',$l,$m); $c['group']=$m[1]??'';
        preg_match('/,(.*)$/',$l,$m); 
        $channelName = $m[1]??'';
        // Clean the channel name
        $channelName = preg_replace('/\s*\([^)]*\)/', '', $channelName);
        $channelName = preg_replace('/\s*\[[^\]]*\]/', '', $channelName);
        $c['name'] = trim($channelName);
    }
    elseif(filter_var($l,FILTER_VALIDATE_URL)){
        $c['url']=$l;
        $out[]=$c;
    }
}

header('Content-Type: application/json');
echo json_encode($out);